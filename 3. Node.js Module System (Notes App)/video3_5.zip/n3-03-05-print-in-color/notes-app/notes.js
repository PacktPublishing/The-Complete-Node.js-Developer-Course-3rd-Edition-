const getNotes = function () {
    return 'Your notes...'
}

module.exports = getNotes